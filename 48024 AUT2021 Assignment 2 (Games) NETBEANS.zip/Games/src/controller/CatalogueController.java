
package controller;

public class CatalogueController {

}
