package controller;

public class RentGameController {

}
